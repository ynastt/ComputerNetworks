# filter

Filter is an example of a how to process JSON log
entries using pipes in your shell.

```sh
yourapp | filter
```

You can try see it in action with `godo filter`
