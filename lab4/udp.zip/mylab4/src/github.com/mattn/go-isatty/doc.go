// Package isatty implements interface to isatty
package isatty
